// 1. Write a program to print Hello Students on the screen.

#include <stdio.h>

int main()
{
    printf("Hello Students");

    

// 2. Write a program to print Hello in the first line and Students in the second line.



    printf("Hello\nStudents");

// 3. Write a program to print “MySirG” on the screen. (Remember to print in double quotes)

    printf("\"MySirG\"");

    return 0;

}    
    