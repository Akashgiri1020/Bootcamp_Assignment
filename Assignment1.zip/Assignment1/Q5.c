// 5. WAP to calculate the length of String using printf function.

#include<stdio.h>

int main(){
    int x;
    x=printf("Ineuron is a best plateform");
    printf("\n");
    printf("the length of \"Ineuron is the best plateform\" is %d",x);
}