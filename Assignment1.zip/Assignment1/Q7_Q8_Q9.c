// 7. WAP to print “%d” on the screen.

#include<stdio.h>
#include<string.h>

int main()
{   
    // 7. WAP to print “%d” on the screen. 
    printf("%%d\n");

    // 8. WAP to print “\n” on the screen.
    printf("\\n");
    printf("\n");

    
    // 9. WAP to print “\\” on the screen.
    printf("\\\\");


    return 0;
}